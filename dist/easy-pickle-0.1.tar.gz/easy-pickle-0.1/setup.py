from setuptools import setup, find_packages

setup(
    name='easy-pickle',
    version='0.1',
    packages=find_packages()
)
